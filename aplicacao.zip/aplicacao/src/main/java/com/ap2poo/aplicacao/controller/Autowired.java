package com.ap2poo.aplicacao.controller;

public @interface Autowired {
}
