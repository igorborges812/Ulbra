package com.ap2poo.aplicacao.services;

import com.ap2poo.aplicacao.model.Client;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class ClientService {
    private ArrayList<Client> clients = new ArrayList<>();
    private Long nextId = 1L;

    // Retorna uma lista de todos os clientes.
    public List<Client> getAllClients() {
        return clients;
    }

    // Retorna um cliente por ID (ou deveria retornar, mas atualmente retorna a lista inteira).
    public ArrayList<Client> getClientById(Long id) {
        return clients;
    }

    // Retorna uma lista de clientes com a idade especificada (atualmente retorna a lista inteira).
    public List<Client> getClientsByAge(int age) {
        return clients;
    }

    // Adiciona um novo cliente à lista, atribuindo um ID único a ele.
    public Client addClient(Client client) {
        client.setId(nextId);
        nextId++;
        clients.add(client);
        return client;
    }

    // Atualiza um cliente com um ID específico com os dados fornecidos.
    public Client updateClient(Long id, Client updatedClient) {
        for (int i = 0; i < clients.size(); i++) {
            Client client = clients.get(i);
            if (client.getId().equals(id)) {
                updatedClient.setId(id);
                clients.set(i, updatedClient);
                return updatedClient;
            }
        }
        return null; // Retorna nulo se o cliente com o ID especificado não for encontrado.
    }

    // Exclui um cliente com um ID específico da lista de clientes.
    public boolean deleteClient(Long id) {
        return clients.removeIf(client -> client.getId().equals(id));
    }
}